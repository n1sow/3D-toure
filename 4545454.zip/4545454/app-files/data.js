var APP_DATA = {
  "scenes": [
    {
      "id": "0-img_20241211_091815_00_158",
      "name": "IMG_20241211_091815_00_158",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.1539471502068555,
          "pitch": 0.16321895765698358,
          "rotation": 0,
          "target": "1-img_20241211_092812_00_161"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-img_20241211_092812_00_161",
      "name": "IMG_20241211_092812_00_161",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.547564491216157,
          "pitch": 0.3209769207841866,
          "rotation": 0,
          "target": "0-img_20241211_091815_00_158"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-img_20241211_094007_00_164",
      "name": "IMG_20241211_094007_00_164",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1520,
      "initialViewParameters": {
        "yaw": -0.3982653785152799,
        "pitch": 0.30452850774417506,
        "fov": 1.4016564304616623
      },
      "linkHotspots": [
        {
          "yaw": 2.5634371294241145,
          "pitch": 0.17987203245402839,
          "rotation": 0,
          "target": "0-img_20241211_091815_00_158"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -2.982530782102536,
          "pitch": 0.09379188058834131,
          "title": "Телевизор xiaomi",
          "text": "Text"
        },
        {
          "yaw": -3.1309263585439826,
          "pitch": 0.4025364766650892,
          "title": "Яндекс станция",
          "text": "Text"
        },
        {
          "yaw": -2.942068189617096,
          "pitch": -0.18614370380234568,
          "title": "камера xiaomi",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
